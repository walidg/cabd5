#!/bin/bash
. ./$1
apt-get -y install git
cd $gitPath
/usr/bin/git clone $gitHost