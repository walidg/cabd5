#!/bin/bash

. conf/docker.conf
docker build -t $dockerName .