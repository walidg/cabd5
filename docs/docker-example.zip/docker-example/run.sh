#!/bin/bash

. conf/docker.conf
docker run -d -p $port1expose:$port1internal -it $dockerName /bin/bash
